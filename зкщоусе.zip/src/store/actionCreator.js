import * as taskAction from "./reducers/task/actions";

export const actions = {
    ...taskAction
}